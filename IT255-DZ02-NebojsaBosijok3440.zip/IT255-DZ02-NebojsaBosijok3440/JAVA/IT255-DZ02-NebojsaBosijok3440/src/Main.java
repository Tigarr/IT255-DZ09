
import java.io.IOException;



/**
 *
 * @author Nesa
 */
public class Main {

    
    public static void main(String[] args) throws IOException {
        System.out.println("---------->PREZENTACIJA GET METODE<----------");
    GetAndPost.MyGETRequest();
        System.out.println("---------->PREZENTACIJA POST METODE<----------");
    GetAndPost.MyPOSTRequest();
}

    
    
}
