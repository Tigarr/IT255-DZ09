export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyDz6m72_Dpt-BHFezqY4oLL2QLWCY5DG28",
    authDomain: "oshop-917c7.firebaseapp.com",
    databaseURL: "https://oshop-917c7.firebaseio.com",
    projectId: "oshop-917c7",
    storageBucket: "oshop-917c7.appspot.com",
    messagingSenderId: "1073230641521",
    appId: "1:1073230641521:web:ffad78801f755b50cf5ed0",
    measurementId: "G-P8Y931JQ9M"
  }
};
